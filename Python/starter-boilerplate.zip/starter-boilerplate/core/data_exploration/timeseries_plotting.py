import seaborn as sns

def get_plot_by_customer(df_processed):
    """
    Explanation

    :param pandas.DataFrame df_processed: Dataframe with consistent data
    :return: Return
    :rtype: pandas.DataFrame
    """
    return sns.plot(df_processed.groupby('customer'))
