# Hypothetical Example
def get_acf_pacf(df_processed):
    """
    This function is used to calculate AutoCorrelation Function and Partial AutoCorrelation Function

    :param pandas.DataFrame df_processed: Dataframe with consistent data
    :return: A Dataframe with statistics grouped by x, y, z
    :rtype: pandas.DataFrame
    """
    acf = df_processed.get_acf()
    pacf = df_processed.get_pacf()
    return df_processed.agg().apply(acf, pacf)
