from core.data_processing.feature1 import slice_feature1
from core.utils.logger import setup_logger
from core.utils.proj_config import create_dir

def processing_workflow(df):
    """
    Creation of all features

    :param pandas.dataframe df: the whole dataframe
    :return: the dataframe enriched with all the features
    :rtype: pandas.dataframe
    """
    return df

def clean_data_workflow(params):
    """
    Workflow for filtering data and make it lighter by typing the columns that we want to keep

    :param str path_to_whole_dataset: path to the csv file
    :param dict data_types: Dict containing data types with key column and value is type
    :param dict column_names: Mapping between old and new column names
    :param dict sub_axe_mapping: Mapping between old and new sub_axe names
    :param list material_groups: Material groups that should be kept in the processing.
    :param list divergent_purchases: list of sensible Purchase Restrictions
    :return: The dataframe with only useful columns and that should fit on RAM
    :rtype: pandas.DataFrame
    """
    # Using log
    columns_to_keep = list(params.keys())
    setup_logger()
    logging.info('%s log test', columns_to_keep)

    return None