from core.data_exploration.timeseries_plotting import get_plot_by_customer
from core.data_exploration.timeseries_statistics import get_acf_pacf

def analyze_data_workflow(params):
    """
    Meaning

    :param list validated_divergents_list: list of known divergents, should come from config file.
    :param pandas.DataFrame df_clustered: Dataframe, output of clustering workflow
    :param float quantile_threshold: Value of quantile threshold desired. from 0 to 1
    :param pandas.DataFrame df_total_hairdressers: Dataframe with salons_code and amounts
    :return: a list of suspected divergents
    """
    return None
