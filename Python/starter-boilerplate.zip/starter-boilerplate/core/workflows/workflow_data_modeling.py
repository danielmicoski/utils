from core.data_modeling.clustering import Clustering

def clustering_workflow(params):
    """
    The main method of the workflow.
    Complete missing data with imputation, normalize data (center and reduce), build the clusters

    :param pandas.dataFrame d_f: the DataFrame with merged features from the features engineering workflow.
    :param integer n_clusters: the number of clusters set in the config file.
    :param str load_model: boolean config parameter from the config file.
    :param string path: config parameter about the path to save/load the model.
    :param string filename: the name under which we save the model.

    :return: a DataFrame with, for each customer, the cluster id assigned.
    :rtype: pandas.DataFrame
    """
    return df_normalized
