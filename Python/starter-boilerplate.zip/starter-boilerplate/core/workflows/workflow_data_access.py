import logging
from core.data_access.data_accessing import get_azure_connection,download_blob_file,upload_blob_file


def data_input_workflow(account_name, account_key,container_name,blob_files,path_output,download_files=True):
    """
    Workflow for connect to Azure and downloads input data.

    :param str account_name: Azure account name.
    :param str account_key: Key to connect on Azure cloud.
    :param str container_name: Azure container name.
    :param list blob_files: Blob file names to download.
    :param str path_output: path where files will be saved.
    :param str download_file: if files already downloaded (== False), then, data_input_workflow won't need to download files
    :return: Status of each downloaded file
    :rtype: list
    """

    if download_files == 'False':
        return ['Files already downloaded. If you want to download again, change download_files on config.json for True.']

    azure_connect = get_azure_connection(account_name, account_key)
    path_files = []
    for blob in blob_files:
        print(blob)
        status_blob_download = download_blob_file(azure_connect, container_name, blob, path_output+blob)
        if status_blob_download == False:
            path_files.append(path_output+blob+': Error')
        else:
            path_files.append(path_output+blob+': Success')
    return path_files

def data_output_workflow(account_name, account_key,container_name,files_to_blob,path_to_upload,upload_files=True):
    """
    Workflow for connect to Azure and uploads data.

    :param str account_name: Azure account name.
    :param str account_key: Key to connect on Azure cloud.
    :param str container_name: Azure container name.
    :param list files_to_blob: Blob file names to upload.
    :param str path_to_upload: path where files are saved.
    :param str upload_files: if files already uploaded (== False), then, data_output_workflow won't need to upload files again.
    :return: Status of each uploaded file
    :rtype: list
    """
    if upload_files == 'False':
        return ['Files already uploaded. If you want to upload again, change upload_files on config.json for True.']

    azure_connect = get_azure_connection(account_name, account_key)
    files_uploaded = []
    status_blob_upload = upload_blob_file(azure_connect, container_name, files_to_blob, path_to_upload+files_to_blob)
    if status_blob_upload == False:
        files_uploaded.append(path_to_upload+files_to_blob+': Error')
    else:
        files_uploaded.append(path_to_upload+files_to_blob+': Success')
    return files_uploaded

