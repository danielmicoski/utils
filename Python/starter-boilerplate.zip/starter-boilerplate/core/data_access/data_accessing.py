from azure.storage.blob import BlobClient

def get_azure_connection(account_name, account_key):
    """
    #TODO DocString
    """
    connection_string = "DefaultEndpointsProtocol=https;AccountName={};AccountKey={};EndpointSuffix=core.windows.net".format(account_name,account_key)
    return connection_string

def download_blob_file(connection,container_name,blob_name,path_output):
    """
    #TODO DocString
    """
    #TODO Try Except
    blob_file = BlobClient.from_connection_string(conn_str=connection, container_name=container_name, blob_name=blob_name)

    with open(str(path_output), "wb") as my_blob:
        blob_data = blob_file.download_blob()
        blob_data.readinto(my_blob)
    return True

def upload_blob_file(connection,container_name,blob_name,path_to_upload):
    """
    #TODO DocString
    """
    #TODO Try Except
    blob_file = BlobClient.from_connection_string(conn_str=connection, container_name=container_name, blob_name=blob_name)

    with open(str(path_to_upload+blob_name), "rb") as data:
        blob_file.upload_blob(data)
    return True