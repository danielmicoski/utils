import pandas as pd

def slice_feature1(df):
    """
    This feature represents some task developed on data_processing 

    :param pandas.dataframe df: the whole dataframe
    :return: the dataframe enriched with the features
    :rtype: pandas.dataframe
    """
    df = df[df['slice something']]
    
    return df

def aggregate_columns_by_feature1(df):
    """
    This feature represents some task developed on data_processing 

    :param pandas.dataframe df: the whole dataframe
    :return: the dataframe enriched with the features
    :rtype: pandas.dataframe
    """
    agg_df = df.agg({'A' : ['sum', 'min'], 'B' : ['min', 'max']})
    return agg_df 
    