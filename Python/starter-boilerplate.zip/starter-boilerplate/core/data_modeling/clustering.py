import pickle
from sklearn.cluster import KMeans
from sklearn.base import BaseEstimator, ClusterMixin


class Clustering(BaseEstimator, ClusterMixin):
    """
    Built class to load, save, fit and predict array values from a data set.

    Attributes:
        n_clusters (int) : Number of clusters we want for the model
        random_state (int) : the seed used by the random number generator
        kmeans (NoneType) : Attribute used to run the model
    """
    def __init__(self, n_clusters=4, random_state=104341):

        self.n_clusters = n_clusters
        self.random_state = random_state
        self.kmeans = None

    def fit(self, X):
        self.kmeans = KMeans(self.n_clusters, random_state=self.random_state)
        self.kmeans.fit(X)

    def predict(self, X):
        y = self.kmeans.predict(X)
        return y

    @classmethod
    def load_model(cls, path):
        with open(path, "rb") as input_file:
            return pickle.load(input_file)

    def save_model(self, path, filename):
        with open(path+filename, "wb") as output_file:
            pickle.dump(self, output_file)
