import datetime
import logging
import os


def setup_logger():
    if not os.path.exists('./log_files/'):
        os.makedirs('./log_files')

    logging.basicConfig(format='[%(asctime)s][%(levelname)s] %(message)s',
                        level=logging.DEBUG,
                        datefmt='%m/%d/%Y %H:%M:%S',
                        filename='./log_files/log_' + '{:%d%m%Y_%H%M}.log'.format(datetime.datetime.now())
                        )
