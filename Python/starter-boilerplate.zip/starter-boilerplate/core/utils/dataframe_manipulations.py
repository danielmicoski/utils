import pandas as pd

# Put here dataframe manipulations snippets that you will might use more than once or if snippets was important adn generic 
# See example bellow
def convert_columns_to_date(df, column_list):
    """
    Cast some columns of a dataframe as date

    :param pandas.Dataframe df: the dataframe whose columns are to cast
    :param list column_list: the column list
    :return: the dataframe with the casted columns and the others
    :rtype: pandas.Dataframe
    """
    for column in column_list:
        df[column] = pd.to_datetime(df[column], errors='coerce')
    return df
