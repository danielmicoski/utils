import json
import pandas as pd
import os

def import_config(json_path):

    with open(json_path, encoding='utf-8') as json_str:
        json_data = json.load(json_str)

    return json_data

def create_dir(directory):
    try:
        if not os.path.exists(directory):
            os.makedirs(directory)
            dir_name = directory.split('/')[-1] if directory.split('/')[-1] != '' else directory.split('/')[-2]
            print('Directory {0} created'.format(dir_name))
            return True
    except FileExistsError:
        print('Error creating directory with path {0}'.format(directory))
        return False