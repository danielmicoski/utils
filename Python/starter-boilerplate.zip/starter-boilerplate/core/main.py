import logging
import datetime
import time
import click

from core.workflows.workflow_data_access import data_input_workflow, data_output_workflow
from core.workflows.workflow_data_processing import processing_workflow
from core.workflows.workflow_data_exploration import analyze_data_workflow
from core.workflows.workflow_data_modeling import clustering_workflow
from saloncentric_fraud_detection.utils.retrieve_config import retrieve_config, import_config
from saloncentric_fraud_detection.utils.logger import setup_logger


@click.command()
@click.option("--param", default="value_default", help="explanation")
def main(config_path):
    setup_logger()
    timing = time.time()
    logging.info('Starting: main')

    logging.info('Starting: data extract')
    config = import_config(config_path)
    
    files = data_input_workflow(account_name = config['data']['account_name'],\
                                account_key = config['data']['account_key'],\
                                container_name = config['data']['container_name'],\
                                blob_files = blob_files,\
                                path_output = config['data']['data_path'],\
                                download_files = config['data']['download_files'])

    logging.info('Starting: data preparation')

    df_processed = processing_workflow(df)

    logging.info('Starting: data exploration')

    visualizations = analyze_data_workflow(df)

    logging.info('Starting: clustering')
    df_clustered = clustering_workflow(params)
    df_clustered.to_csv(config['data']['after_clustering_output'], index=False)
    files_up = data_output_workflow(account_name = config['data']['account_name'],\
                                account_key = config['data']['account_key'],\
                                container_name = config['data']['container_name'],\
                                files_to_blob = [config['data']['output_file']],\
                                path_to_upload = config['data']['data_path'],\
                                upload_files = config['data']['upload_files'])
    

    logging.info('Ending: main')
    ending_timing = time.time()
    logging.info('Total execution time: %s seconds',
                 round((ending_timing - timing), 2))


if __name__ == '__main__':
    main()
