from unittest import TestCase

import pandas as pd
from pandas.testing import assert_frame_equal

from core.data_exploration.timeseries_plotting import get_plot_by_customer


class TestTimeseriesPlotting(TestCase):
    # pylint: disable=R0201
    def test_get_plot_by_customer(self):
        self.assertEquals(1,1)