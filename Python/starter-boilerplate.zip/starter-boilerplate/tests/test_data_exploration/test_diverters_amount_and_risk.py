from unittest import TestCase

import pandas as pd
from pandas.testing import assert_frame_equal

import numpy as np

from saloncentric_fraud_detection.diverters_detection.diverters_amount_and_risk import divergents_amount_and_risk


class TestDivertersAmount(TestCase):

    # pylint: disable=R0201
    def test_divergents_amount_and_risk(self):
        # Given
        suspected_divergents = pd.DataFrame({'max': [2, 3, 4, 5, 6],
                                             'median': [1, 2, 3, 4, 5],
                                             'mean': [1.1, 2.2, 3.3, 4.4, 5.5],
                                             'distance_to_centroid': [1.2, 2.3, 3.4, 4.5, 5.6]})
        suspected_divergents.index = ["B", "C", "F", "G", "H"]
        suspected_divergents.index.name = "Sold_to_code"

        df_salons_code_amount = pd.DataFrame({"Cumulative_Amt_BL_CM_Gross": [12, 23, 34, 45, 56, 67, 78, 89]})
        df_salons_code_amount.index = ["A", "B", "C", "D", "E", "F", "G", "H"]

        expected_scaled_features = pd.DataFrame({"Sold_to_code": ["B", "C", "F", "G", "H"],
                                                 "risk": [1, 0.75, 0.5, 0.25, 0],
                                                 "Cumulative_Amt_BL_CM_Gross": [23, 34, 67, 78, 89],
                                                 "risk_category": [5, 4, 3, 2, 1]})
        expected_scaled_features['risk_category'] = expected_scaled_features['risk_category'].astype(np.int32)
        # When
        scaled_features = divergents_amount_and_risk(suspected_divergents=suspected_divergents,
                                                     df_salons_code_amount=df_salons_code_amount)
        # Then
        assert_frame_equal(
            expected_scaled_features[['Sold_to_code', 'Cumulative_Amt_BL_CM_Gross', 'risk', "risk_category"]],
            scaled_features[['Sold_to_code', 'Cumulative_Amt_BL_CM_Gross', 'risk', "risk_category"]])
