import unittest
import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal
from core.data_modeling.clustering import Clustering


class TestClustering(unittest.TestCase):
    def test_fit(self):
        clustering = Clustering()
        self.assertIsInstance(clustering)

