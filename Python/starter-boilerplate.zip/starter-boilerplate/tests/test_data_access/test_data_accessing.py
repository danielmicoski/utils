import unittest
import numpy as np
import pandas as pd

from pandas.testing import assert_frame_equal

from core.data_access.data_accessing import get_azure_connection, download_blob_file, upload_blob_file
from core.utils.proj_config import import_config

class TestDataAccessing(unittest.TestCase):
    data_types = {
        "feature1":np.float64,
        "feature2": "category"
    }

    def test_get_azure_connection(self):
        # Given
        # TODO Refactor to receive json parameters to test
        account_name = "lorealstoragepoc"
        account_key = "yM5iNyG9MCXU9U9AYEB+HX/+XiVXmzCrKwLqTvrdb32tf/vNpRld6VqTioGFf9jJMf2dZ6ZscBRIqMwK4K8BiQ"

        # When
        test_connection = get_azure_connection(account_name, account_key)

        # Then
        self.assertIs(type(test_connection), str)
