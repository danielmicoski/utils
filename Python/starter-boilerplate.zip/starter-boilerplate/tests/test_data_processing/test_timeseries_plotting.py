import unittest

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal

from core.data_exploration.timeseries_plotting import get_plot_by_customer


class TestTimeseriesPlotting(unittest.TestCase):
    data_types = {"something":"anything"}

    def test_get_plot_by_customer(self):
        # Given
        df_test = pd.DataFrame({
            "x":1,
            "y":2,
            "z":3
        })
       
        # When
        plot_df = get_plot_by_customer(df_test)

        # Then
        self.assertIsNotNone(plot_df)