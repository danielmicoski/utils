import unittest

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal

from core.data_exploration.timeseries_statistics import get_acf_pacf


class TestTimeseriesStatistics(unittest.TestCase):
    data_types = {"something":"anything"}

    def test_get_acf_pacf(self):
        # Given
        values_to_test = pd.DataFrame({
            "x":1,
            "y":2,
            "z":3
        })

        expected_acf_pcf_values = pd.DataFrame({
            "ACF": [1, 2 ],
            "PACF": [3, 4 ]
        })

        # When

        values_to_test = get_acf_pacf(values_to_test, self.data_types)

        # Then
        self.assert_frame_equal(values_to_test, exexpected_acf_pcf_valuesp)